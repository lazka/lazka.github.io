///// Includes /////////////////////////////////////////////////////////////////
#include "ic.hpp"
////////////////////////////////////////////////////////////////////////////////

namespace ic
{
	///// Console //////////////////////////////////////////////////////////////
	const COORD Console::origin = {0, 0};

	Console::Console ()
	: hout(GetStdHandle(STD_OUTPUT_HANDLE))
#ifndef IMPROVED_CONSOLE_WIN9X_COMPATIBLE
	, SetConsoleDisplayMode(0)
#endif
	{
#ifndef IMPROVED_CONSOLE_WIN9X_COMPATIBLE
		// Load already implemented WinAPI-Functions without declaration in <windows.h>
		loadUndeclaredFunctions();
#endif

		// Disable ENABLE_WRAP_AT_EOL_OUTPUT
		SetConsoleMode(hout,ENABLE_PROCESSED_OUTPUT);
		reset();
	}

	Console::~Console ()
	{
		reset();
		// Reenable ENABLE_WRAP_AT_EOL_OUTPUT
		SetConsoleMode(hout,ENABLE_PROCESSED_OUTPUT|ENABLE_WRAP_AT_EOL_OUTPUT);
	}

	Console& Console::getInstance ()
	{
		static Console object;
		return object;
	}

	void Console::reset ()
	{
		show();
		normalize();

		setBgColor(BG_BLACK);
		setTextColor(FG_WHITE);
		setCaretSize(0);
		setPos(150,150);
		setSize(80,25);

		clearScreen();

#ifndef IMPROVED_CONSOLE_WIN9X_COMPATIBLE
		setFullscreen(false);
#endif
	}

	void Console::show ()
	{
		ShowWindow(getCWND(),SW_SHOW);
	}

	void Console::hide ()
	{
		ShowWindow(getCWND(),SW_HIDE);
	}

	void Console::normalize ()
	{
		ShowWindow(getCWND(),SW_NORMAL);
	}

	void Console::minimize ()
	{
		ShowWindow(getCWND(),SW_MINIMIZE);
	}

	void Console::maximize ()
	{
		ShowWindow(getCWND(),SW_MAXIMIZE);
	}

	void Console::toggleFullscreen ()
	{
		// Hack for compatibility-mode
		// Fullscreen-mode-toggle by simulating user-keyboard-shourtcut (ALT+RETURN)
		keybd_event(VK_MENU,0x38,0,0);
        keybd_event(VK_RETURN,0x1c,0,0);
        keybd_event(VK_RETURN,0x1c,KEYEVENTF_KEYUP,0);
        keybd_event(VK_MENU,0x38,KEYEVENTF_KEYUP,0);
	}

	void Console::clearScreen (Color color, TCHAR character)
	{
		clearColor(color);
		clearText(character);
	}

	void Console::clearColor (Color color)
	{
		DWORD attrsWritten;
		FillConsoleOutputAttribute(hout,color,getSizeX()*getSizeY(),origin,&attrsWritten);

		setCaret(0,0);
	}

	void Console::clearText (TCHAR character)
	{
		DWORD charsWritten;
		FillConsoleOutputCharacter(hout,character,getSizeX()*getSizeY(),origin,&charsWritten);

		setCaret(0,0);
	}

	TextColor Console::getTextColor () const
	{
		return getTextColor(getCSBI().wAttributes);
	}

	void Console::setTextColor (TextColor color)
	{
		SetConsoleTextAttribute(hout,static_cast<WORD>(color|getBgColor()));
	}

	BgColor Console::getBgColor () const
	{
		return getBgColor(getCSBI().wAttributes);
	}

	void Console::setBgColor (BgColor color)
	{
		SetConsoleTextAttribute(hout,static_cast<WORD>(color|getTextColor()));
	}

	WORD Console::getCaretX () const
	{
		return getCSBI().dwCursorPosition.X;
	}

	WORD Console::getCaretY () const
	{
		return getCSBI().dwCursorPosition.Y;
	}

	void Console::setCaret (WORD x, WORD y)
	{
		COORD position;
		position.X = x;
		position.Y = y;
		SetConsoleCursorPosition(hout,position);
	}

	DWORD Console::getCaretSize () const
	{
		CCI cci = getCCI();
		return cci.bVisible ? cci.dwSize : 0;
	}

	void Console::setCaretSize (DWORD size)
	{
		CCI cci;
		cci.bVisible = size > 0 ? TRUE : FALSE;
		// Size must be between 0 and 100
		cci.dwSize = size > 0 && size < 100 ? size : 100;
		SetConsoleCursorInfo(hout,&cci);
	}

	DWORD Console::getPosX () const
	{
		RECT rect;
		GetWindowRect(getCWND(),&rect);

		return rect.left;
	}

	DWORD Console::getPosY () const
	{
		RECT rect;
		GetWindowRect(getCWND(),&rect);

		return rect.top;
	}

	void Console::setPos (DWORD x, DWORD y)
	{
		SetWindowPos(getCWND(),0,x,y,0,0,SWP_NOACTIVATE|SWP_NOOWNERZORDER|SWP_NOSIZE|SWP_NOZORDER);
	}

	WORD Console::getSizeX () const
	{
		return getCSBI().dwSize.X;
	}

	WORD Console::getSizeY () const
	{
		return getCSBI().dwSize.Y;
	}

	void Console::setSize (WORD x, WORD y)
	{
		zeroSize();

		COORD bufSize;
		// Don't replace with min()-Macro, problems with DevCpp
		bufSize.X = x < getMaxSizeX() ? x : getMaxSizeX();
		bufSize.Y = y < getMaxSizeY() ? y : getMaxSizeY();
		SetConsoleScreenBufferSize(hout,bufSize);

		SMALL_RECT wndSize;
		wndSize.Top = 0;
		wndSize.Left = 0;
		wndSize.Right = bufSize.X - 1;
		wndSize.Bottom = bufSize.Y - 1;
		SetConsoleWindowInfo(hout,TRUE,&wndSize);
	}

	WORD Console::getMaxSizeX () const
	{
		return GetLargestConsoleWindowSize(hout).X;
	}

	WORD Console::getMaxSizeY () const
	{
		return GetLargestConsoleWindowSize(hout).Y;
	}

	std::basic_string<TCHAR> Console::getTitle () const
	{
		static const size_t MAX_TITLE_LEN = 64 * 1024;

		TCHAR title [MAX_TITLE_LEN];
		GetConsoleTitle(title,MAX_TITLE_LEN);

		return title;
	}

	void Console::setTitle (const std::basic_string<TCHAR>& title)
	{
		SetConsoleTitle(title.c_str());
	}

#ifndef IMPROVED_CONSOLE_WIN9X_COMPATIBLE
	bool Console::isFullscreen () const
	{
        DWORD flags = 0;
		GetConsoleDisplayMode(&flags);

		return (flags & CONSOLE_FULLSCREEN_HARDWARE) > 0;
	}

	void Console::setFullscreen (bool on)
	{
		COORD newDim;
		DWORD flags = on ? CONSOLE_FULLSCREEN_MODE : CONSOLE_WINDOWED_MODE;
		SetConsoleDisplayMode(hout,flags,&newDim);
	}
#endif

	Console::CCI Console::getCCI () const
	{
		CCI cci;
		GetConsoleCursorInfo(hout,&cci);

		return cci;
	}

	Console::CSBI Console::getCSBI () const
	{
		CSBI csbi;
		GetConsoleScreenBufferInfo(hout,&csbi);

		return csbi;
	}

	HWND Console::getCWND () const
	{
#ifndef IMPROVED_CONSOLE_WIN9X_COMPATIBLE
		return GetConsoleWindow();
#else
		TCHAR oldTitle [512];
		_tcscpy(oldTitle,getTitle().c_str());
		TCHAR newTitle [512];
		_stprintf(newTitle,TEXT("%d%d"),GetTickCount(),GetCurrentProcessId());

		SetConsoleTitle(newTitle);
		HWND cwnd = FindWindow(0,newTitle);
		SetConsoleTitle(oldTitle);

		return cwnd;
#endif
	}

#ifndef IMPROVED_CONSOLE_WIN9X_COMPATIBLE
	void Console::loadUndeclaredFunctions ()
	{
		HMODULE kernel32 = GetModuleHandle(TEXT("kernel32.dll"));

		// Load already implemented WinAPI-Functions without declaration in <windows.h>
		SetConsoleDisplayMode = reinterpret_cast<SETCONSOLEDISPLAYMODE>(GetProcAddress(kernel32,"SetConsoleDisplayMode"));
	}
#endif

	void Console::zeroSize ()
	{
		COORD bufSize;
		bufSize.X = 1;
		bufSize.Y = 1;
		SetConsoleScreenBufferSize(hout,bufSize);

		SMALL_RECT wndSize;
		wndSize.Top = 0;
		wndSize.Left = 0;
		wndSize.Right = 0;
		wndSize.Bottom = 0;
		SetConsoleWindowInfo(hout,TRUE,&wndSize);
	}

	Console& con = Console::getInstance();
	////////////////////////////////////////////////////////////////////////////
}
