#include "ic/ic.h"
#include <stdio.h>
#include <time.h>
#include "eing/eing.h"

#define NUM_FELDER 12
#define HEIGHT 25

#define BG_COLOR 3*16
#define FIELD_COLOR 15*16
#define INPUT_COLOR 0
#define TEXT_COLOR 15

#define bgc(x) con.setBgColor(static_cast<BgColor>(x))
#define textc(x) con.setTextColor(static_cast<TextColor>(x))

void draw_feld(int x, int y, int length);
void refresh_data(int x, int y, double wert);
void draw_info(char text[]);
int zufall(void);

int main(int argc, char *argv[])
{
	int x,y,z,i,u,f;
	FILE *log;

	/* Struktur der Eingabefelder */
	struct feld
	{
		int		x,
			y,
			length,
			max,
			min;
		double  wert;
		char	title[50];
	}eingabe[NUM_FELDER];

	float monster[15];
	int end;
	unsigned long count;

	/* Hintergrund */
	bgc(BG_COLOR);
	textc(TEXT_COLOR);
	con.setSize(75,HEIGHT+1);
	con.setTitle(_T("Lazka's Zeal-Hitcounter"));
	for(y=0;y<HEIGHT;y++)
	{
		for(x=0;x<75;x++)
		{
			if(y==1 || y==(HEIGHT-3) || y==(HEIGHT-1))
				printf("%c",205);
			else
				putch(' ');
		}
		putch('\n');
	}

	/* �berschrift des Formulares */
	con.setCaret(25,1);
	printf("%c Zeal-Hitcounter V2.2 %c",185,204);

	/* Setze die Werte auf 0 */
	for(i=0;i<NUM_FELDER;i++)
	{
		eingabe[i].x   		= 0;
		eingabe[i].y		= 0;
		eingabe[i].length	= 0;
		eingabe[i].min		= -1;
		eingabe[i].max		= -1;
		eingabe[i].wert		= 0;
		eingabe[i].title[0]	='\0';
	}

	/* Auslesen vorhandener Werte aus der Save-Datei */
	if(log=fopen("hcounter.save","rb"))
	{
		for(i=0;i<NUM_FELDER;i++)
			fread(&eingabe[i].wert,sizeof(eingabe[i].wert),1,log);
		fclose(log);
	}

	/* Konfigurieren der Eingabefelder... */
	eingabe[0].x   		= 20;
	eingabe[0].y		= 5;
	eingabe[0].min		= 1;
	eingabe[0].length	= 11;
	strcpy(eingabe[0].title,"Min. Damage:");


	eingabe[1].x   		= 20;
	eingabe[1].y		= 7;
	eingabe[1].min		= 1;
	eingabe[1].length	= 11;
	strcpy(eingabe[1].title,"Max. Damage:");

	eingabe[2].x   		= 20;
	eingabe[2].y		= 11;
	eingabe[2].min		= 1;
	eingabe[2].max		= 100;
	eingabe[2].length	= 11;
	strcpy(eingabe[2].title,"Chance to hit:");

	eingabe[3].x   		= 20;
	eingabe[3].y		= 13;
	eingabe[3].min		= 0;
	eingabe[3].max		= 100;
	eingabe[3].length	= 11;
	strcpy(eingabe[3].title,"Crushing Blow:");

	eingabe[4].x   		= 20;
	eingabe[4].y		= 15;
	eingabe[4].min		= 0;
	eingabe[4].max		= 100;
	eingabe[4].length	= 11;
	strcpy(eingabe[4].title,"Deadly Strike:");

	eingabe[5].x   		= 20;
	eingabe[5].y		= 17;
	eingabe[5].min		= 0;
	eingabe[5].max		= 100;
	eingabe[5].length	= 11;
	strcpy(eingabe[5].title,"Static:");

	eingabe[6].x   		= 55;
	eingabe[6].y		= 5;
	eingabe[6].min		= 1;
	eingabe[6].max		= 2;
	eingabe[6].length	= 11;
	strcpy(eingabe[6].title,"Monstertype:");

	eingabe[7].x   		= 55;
	eingabe[7].y		= 7;
	eingabe[7].min		= 1;
	eingabe[7].max		= 15;
	eingabe[7].length	= 11;
	strcpy(eingabe[7].title,"Number of Monsters:");

	eingabe[8].x   		= 55;
	eingabe[8].y		= 9;
	eingabe[8].min		= 1;
	eingabe[8].length	= 11;
	strcpy(eingabe[8].title,"Monsterlife:");

	eingabe[9].x   		= 55;
	eingabe[9].y		= 13;
	eingabe[9].min		= 0;
	eingabe[9].max		= 100;
	eingabe[9].length	= 11;
	strcpy(eingabe[9].title,"Phys. Resistance:");

	eingabe[10].x   	= 55;
	eingabe[10].y		= 15;
	eingabe[10].min		= 0;
	eingabe[10].max		= 100;
	eingabe[10].length	= 11;
	strcpy(eingabe[10].title,"Light. Resistance:");

	eingabe[11].x   	= 55;
	eingabe[11].y		= 17;
	eingabe[11].min		= 1;
	eingabe[11].max		= 8;
	eingabe[11].length	= 11;
	strcpy(eingabe[11].title,"Players in game:");

	/* Ausgabe aller Felder in der Konsole */
	for(i=0;i<NUM_FELDER;i++)
	{
		/* Text rechtsb�ndig schreiben und falls zu lang abschneiden */
		bgc(BG_COLOR);
		textc(TEXT_COLOR);

		if((int)strlen(eingabe[i].title) < eingabe[i].x)
			con.setCaret(eingabe[i].x-int(strlen(eingabe[i].title))-1,eingabe[i].y);
		else
		{
			con.setCaret(0,eingabe[i].y);
			eingabe[i].title[eingabe[i].x-1]='\0';
		}

		puts(eingabe[i].title);

		/* Eingabefeld zeichnen */
		draw_feld(eingabe[i].x, eingabe[i].y, eingabe[i].length);

		/* Falls Daten aus Save-Datei gelesen wurden ins Feld einf�gen */
		if(eingabe[i].wert || eingabe[i].min>0)

			/* Max/Min der Daten */
			if(eingabe[i].min>=0)
				eingabe[i].wert = (eingabe[i].wert < eingabe[i].min) ? eingabe[i].min : eingabe[i].wert;
		if(eingabe[i].max>=0)
			eingabe[i].wert = (eingabe[i].wert > eingabe[i].max) ? eingabe[i].max : eingabe[i].wert;

		refresh_data(eingabe[i].x, eingabe[i].y, eingabe[i].wert);

		if(!eingabe[i].wert && eingabe[i].min<=0)
			draw_feld(eingabe[i].x, eingabe[i].y, eingabe[i].length);
	}

	/*	Best�tigen/Ausw�hlen mit ENTER und springen zum	*/
	/*	vorigen bzw. n�chsten Feld mit den Pfeiltasten	*/
	i=0;
	draw_info("   Input [ENTER]    Navigate [ARROW KEYS]    Save [F5]    Calculate [F9]");
	con.setCaret(eingabe[i].x,eingabe[i].y);
	con.setCaretSize(CARET_OVERWRITE);

	while(1) 
	{
		u=getch();
		if(u==0x0D)    // Start der Eingabe mit Enter
		{
			draw_info(">> Confirm input by pressing ENTER");
			draw_feld(eingabe[i].x, eingabe[i].y, eingabe[i].length);

			con.setCaret(eingabe[i].x+1,eingabe[i].y);
			textc(INPUT_COLOR);
			con.setCaretSize(10);

			eingabe[i].wert=input("<7");  // Eingabe

			con.setCaretSize(CARET_OVERWRITE);
		}
		else if(u==224)			//Pfeiltaste gedr�ckt
		{
			u=getch();
			if(u==80)		// Pfeiltaste UNTEN
			{
				if(i+1<NUM_FELDER)
					++i;
				else
					i=0;
			}
			else if(u==72)	// Pfeiltaste OBEN
			{
				if(i>0)
					--i;
				else
					i=NUM_FELDER-1;
			}
			else if(u==77)  // Pfeiltaste RECHTS
			{
				if((i+NUM_FELDER/2) < NUM_FELDER)
					i+=NUM_FELDER/2;
				else
					i-=NUM_FELDER/2;
			}
			else if(u==75)  // Pfeiltaste LINKS
			{
				if((i-NUM_FELDER/2) >= 0)
					i-=NUM_FELDER/2;
				else
					i+=NUM_FELDER/2;
			}
			//Bild-AUF/AB - Pfailtasten links/rechts: inc/dec der zahl
			else if(u==81)
				--eingabe[i].wert;
			else if(u==73)
				++eingabe[i].wert;
		}
		// Speichern oder Rechnen
		else if(!u)         
		{
			u=getch();
			if(u==63)
			{
				// Schreiben der Log-Datei

				if(log=fopen("hcounter.save","wb"))
				{
					for(f=0;f<NUM_FELDER;f++)
						fwrite(&eingabe[f].wert,sizeof(eingabe[f].wert),1, log);
					fclose(log);
					draw_info(">> All fields are saved! (hcounter.save)");
					Sleep(1000);
				}
				else
				{
					draw_info(">> Wasn't able to save!!");
					Sleep(1000);
				}
			}
			else if(u==67)
			{
				/* Berechnungsroutine - START */
				count=0;
				draw_info(" ");
				srand( (unsigned)time( NULL ) );

				for(z=0;z<10000;z++)
				{
					for(x=0;x<eingabe[7].wert;x++)
						monster[x]=eingabe[8].wert * (eingabe[11].wert+1) * 0.5;	//Leben definieren

					x=0;
					while(1)
					{
						if(monster[x] > 0)
						{
							++count;
							if((float)zufall() < eingabe[2].wert) //wenn treffer
							{        
								// Crushing Blow
								if((float)zufall() < eingabe[3].wert)
									monster[x] = monster[x] * (1 - (((1/(2*(eingabe[11].wert+1)))/eingabe[6].wert)*(1-eingabe[9].wert/100))) ;

								// Deadly Strike
								if((float)zufall() < eingabe[4].wert)
									monster[x] = monster[x]-((eingabe[0].wert+eingabe[1].wert)/2)*(1-eingabe[9].wert/100)*2;
								else
									monster[x] = monster[x]-((eingabe[0].wert+eingabe[1].wert)/2)*(1-eingabe[9].wert/100);

								//Static
								if((float)zufall() < eingabe[5].wert)
								{
									for(y=0;y<eingabe[7].wert;y++)
									{
										if(monster[y] > eingabe[8].wert/2)
										{
											monster[y] = monster[y]*(1-(0.25*(1-eingabe[10].wert/100)));
											if(monster[y] < eingabe[8].wert/2)
												monster[y] = eingabe[8].wert/2;
										}
									}
								}
							}
						}

						if(monster[x] < 0)
							monster[x] = 0;

						if(x >= eingabe[7].wert-1)
							x=0;	//Index reset wenn num
						else
							++x;

						end=1;	//Check ob alle tot

						for(y=0;y<eingabe[7].wert;y++)
						{
							if(monster[y]>0)
							{
								end=0;
								break;
							}
						}

						if(end)
							break;
					}

					if(!(z%138))
					{
						con.setCaret(z/138+1,HEIGHT-2);
						printf("%c",178);
					}
				}
				/* Berechnungsroutine - ENDE */
				con.setCaret(0,HEIGHT-5);
				for(x=0;x<75;x++)
					putch(' ');
				con.setCaret(31,HEIGHT-5);
				printf(">> %d hits <<",(int)(count/z));
			}
		}

		/* Max/Min der Daten */
		if(eingabe[i].min>=0)
			eingabe[i].wert = (eingabe[i].wert < eingabe[i].min) ? eingabe[i].min : eingabe[i].wert;
		if(eingabe[i].max>=0)
			eingabe[i].wert = (eingabe[i].wert > eingabe[i].max) ? eingabe[i].max : eingabe[i].wert;

		draw_feld(eingabe[i].x, eingabe[i].y, eingabe[i].length);
		refresh_data(eingabe[i].x, eingabe[i].y, eingabe[i].wert);

		if(!eingabe[i].wert && eingabe[i].min<=0)
			draw_feld(eingabe[i].x, eingabe[i].y, eingabe[i].length);


		draw_info("   Input [ENTER]    Navigate [ARROW KEYS]    Save [F5]    Calculate [F9]");
		con.setCaret(eingabe[i].x,eingabe[i].y);
	}
}

/* Feld l�schen bzw. zeichnen */
void draw_feld(int x, int y, int length)
{
	int u;

	bgc(FIELD_COLOR);
	con.setCaret(x,y);
	for(u=0;u<length;u++)
		putch(' ');
}

/* Information links unten anzeigen lassen */
void draw_info(char text[])
{
	int u;

	bgc(BG_COLOR);
	textc(TEXT_COLOR);

	con.setCaret(0,HEIGHT-2);
	printf("%s",text);
	for(u=int(strlen(text));u<75;u++)
		putch(' ');
}

/* Wert in Feld schreiben */
void refresh_data(int x, int y, double wert)
{
	textc(INPUT_COLOR);
	con.setCaret(x+1, y);

	if(wert==(int)wert)
		printf("%d",(int)wert);
	else
		printf("%.1f",wert);
}

int zufall(void)
{
	int r;
	r = (int)(100*rand()/(RAND_MAX+1.0));
	return r;
}
