#include <conio.h>

/*
	Name:	Zahleneingabe v1.1.1
	Author:	Christoph Reiter
	Date:	10.11.05 20:23
	Functions:	# Eingabe mit DOUBLE-R�ckgabe
				# Max- und Minimalstellenanzahl vor und nach Komma
				# Erlauben/Verbieten von Negativwerten
				# L�schfunktion
	Description:	z.B.:	data=eingabe("- >2 <5 . =4")
					#Negativwert und Flie�zahl erlaubt
					#Ganzzahl: 2-5 Stellen
					#genau 4 Nachkommastellen
*/

void getStrOpt(char cSet[], int *iMinint, int *iMaxint, int *iMinfloat, int *iMaxfloat, int *iNeg);
int iPow10(int iNum);

double input(char cSet[])
{
    int iTemp=0, iCint=0, iCfloat=0, iFlag=0, iInvert=0;
    int iMinint=0, iMaxint=10, iMinfloat=0, iMaxfloat=10, iNeg=0;
    double dErg=0, dErgtemp=0;

    getStrOpt(cSet, &iMinint, &iMaxint, &iMinfloat, &iMaxfloat, &iNeg);

    if(iMaxint>10)
        iMaxint=10;
    if(iMaxfloat>10)
        iMaxfloat=10;

    while((iTemp=getch())!='\r' || iCint<iMinint || iCfloat<iMinfloat)
    {
        if(
            (iTemp>='0' && iTemp<='9' && ((iCint<iMaxint && !iFlag) || (iCfloat<iMaxfloat && iFlag)) ) ||
            (iTemp=='0' && !iMaxint && !iCint) ||
            (iTemp=='.' && !iFlag && iMaxfloat>0) ||
            (iTemp=='-' && !iFlag && !iInvert && !iCint && iNeg)
        )
        {
            if(iTemp=='-')
                iInvert=1;
            else if(iTemp=='.')
                iFlag=1;
            else if(!iFlag)
            {
                iCint++;
                dErg=dErg*10+(iTemp-0x30);
            }
            else if(iFlag)
            {
                iCfloat++;
                dErg+=(iTemp-0x30)*(1.0/iPow10(iCfloat));
            }
            putch(iTemp);
        }
        else if(iTemp=='\b' && (iCint || iFlag || iInvert))
        {
            putch('\b');
            putch(' ');
            putch('\b');

            if(iInvert && !iCint && !iCfloat && !iFlag)
                iInvert=0;
            else if(iCint && !iCfloat && !iFlag)
            {
                iCint--;
                dErg=(int)(dErg/10);
            }
            else if(iFlag && !iCfloat)
                iFlag=0;
            else if(iCfloat)
            {
                dErgtemp=(int)dErg;
                dErg-=dErgtemp;
                dErg*=iPow10(iCfloat);
                dErg=(int)(dErg/10);
                iCfloat--;
                dErg/=iPow10(iCfloat);
                dErg+=dErgtemp;
            }
        }
    }

    if(iInvert)
        dErg*=-1;

    return dErg;
}

void getStrOpt(char cSet[], int *iMinint, int *iMaxint, int *iMinfloat, int *iMaxfloat, int *iNeg)
{
    int iStrflag=-1, iStrend=0, iStrtemp=0, i=0, u=0;

    for(i=0;cSet[i]!='\0';i++)
    {
        if(cSet[i]=='.')
            iStrflag=i;
    }
    iStrend=i;

    if(iStrflag<0)
    {
        iStrflag=iStrend;
        *iMaxfloat=0;
    }

    while(iStrend>iStrflag)
    {
        if(cSet[iStrend]>='0' && cSet[iStrend]<='9')
        {
            iStrtemp+=((cSet[iStrend]-0x30)*iPow10(u));
            u++;
        }
        else if(cSet[iStrend]=='=')
        {
            *iMinfloat=*iMaxfloat=iStrtemp;
            break;
        }
        else if(cSet[iStrend]=='>')
        {
            *iMinfloat=iStrtemp;
            iStrtemp=u=0;
        }
        else if(cSet[iStrend]=='<')
        {
            *iMaxfloat=iStrtemp;
            iStrtemp=u=0;
        }
        iStrend--;
    }

    iStrtemp=u=0;

    while(iStrflag>=0)
    {
        if(cSet[iStrflag]>='0' && cSet[iStrflag]<='9')
        {
            iStrtemp+=((cSet[iStrflag]-0x30)*iPow10(u));
            u++;
        }
        else if(cSet[iStrflag]=='=')
        {
            *iMinint=*iMaxint=iStrtemp;
            break;
        }
        else if(cSet[iStrflag]=='>')
        {
            *iMinint=iStrtemp;
            iStrtemp=u=0;
        }
        else if(cSet[iStrflag]=='<')
        {
            *iMaxint=iStrtemp;
            iStrtemp=u=0;
        }
        else if(cSet[iStrflag]=='-')
            *iNeg=1;
        iStrflag--;
    }
}

int iPow10(int iNum)
{
    int iErg;
    for(iErg=1;iNum>0;iNum--)
        iErg*=10;
    return iErg;
}
