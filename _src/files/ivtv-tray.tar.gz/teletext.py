# Copyright 2009 Christoph Reiter <christoph.reiter@gmx.at>
#
# This program is free software; you can redistribute it and/or modify
# it under the terms of the GNU General Public License version 2 as
# published by the Free Software Foundation.

import os

import util

def parse_header(text):
    weekdays = ["mon","tue","wed","thu","fri","sat","sun",
                "mo", "di", "mi", "do", "fr", "sa", "so"]
    months = ["jan", "feb", "mar", "apr", "may", "jun",
            "jul", "aug", "sep", "oct" ,"nov", "dec",
            "mai", "okt", "dez"]
    parts = text.split()
    parts = ["".join(a.split("?")) for a in parts]
    parts = [a for a in parts if a.lower() not in weekdays]
    parts = [a for a in parts if a.lower() not in months]
    parts = [a for a in parts if ":" not in a]
    end = []
    for a in parts:
        if a.lower().endswith("text"):
            a = a[:-4].strip("-")
        nodot = "".join(a.split("."))
        if nodot.isdigit() and len(nodot) > 1:
            continue
        if len(a.split(".")) > 1 and \
            [b for b in a.split(".") if b.isdigit()]:
            continue
        end.append(a.upper())
    return " ".join(end)


def get_current_title():
    import tempfile
    fn = os.path.join(tempfile.gettempdir(), "ivtvt_teletext")
    title = ""
    code, text = util.get_status_output(
        "alevt-cap -timeout 7 -name %s 100" % fn)
    if os.path.isfile(fn):
        line = open(fn).next()
        title = parse_header(line)
        os.remove(fn)
    return title
