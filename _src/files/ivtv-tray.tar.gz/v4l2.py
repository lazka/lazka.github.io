# Copyright 2009 Christoph Reiter <christoph.reiter@gmx.at>
#
# This program is free software; you can redistribute it and/or modify
# it under the terms of the GNU General Public License version 2 as
# published by the Free Software Foundation.

import util
import ttk

def parse_list(text):
    inputs = []
    lines = [line.strip() for line in text.split("\n")]
    for line in lines:
        line = line.split(":")
        if len(line) == 2:
            key, val = line
        else:
            continue
        if key.startswith("Input"):
            input = int(val.strip())
        elif key.startswith("Name"):
            inputs.append((val.strip(), input))
    return inputs

def parse_status(text):
    pair = text.split(":", 1)[-1].strip().split(" ", 1)
    number = pair[0]
    name = pair[1].strip("()").split(":")[0]
    return name, int(number)

def set_video_input(val):
    cmd = "v4l2-ctl --set-input %d" % val
    status, text = util.get_status_output(cmd)
    if status != 0:
        desc = cmd
        desc += "\nled to:\n"
        desc += text
        ttk.ErrorMessage(None, "Failed to set video input", desc).run()

def set_audio_input(val):
    cmd = "v4l2-ctl --set-audio-input %d" % val
    status, text = util.get_status_output(cmd)
    if status != 0:
        desc = cmd
        desc += "\nled to:\n"
        desc += text
        ttk.ErrorMessage(None, "Failed to set audio input", desc).run()

def get_signal():
    cmd = "v4l2-ctl -T"
    code, text = util.get_status_output(cmd)
    line = filter(lambda x: "signal" in x.lower(), text.split("\n"))
    if not line: return False
    strength = line[0].split(":", 1)[-1].split("%", 1)[0]
    print strength
    if int(strength) > 90:
        return True
    return False

def set_frequency(f):
    cmd = "v4l2-ctl --set-freq=%s" % str(f)
    code, text = util.get_status_output(cmd)

def get_audio_input_list():
    code, text = util.get_status_output("v4l2-ctl --list-audio-inputs")
    return parse_list(text)

def get_video_input_list():
    code, text = util.get_status_output("v4l2-ctl --list-inputs")
    return parse_list(text)

def get_video_input():
    code, text = util.get_status_output("v4l2-ctl --get-input")
    return parse_status(text)

def get_audio_input():
    code, text = util.get_status_output("v4l2-ctl --get-audio-input")
    return parse_status(text)
