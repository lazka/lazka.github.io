#!/usr/bin/env python
# -*- coding: utf-8 -*-

# Copyright 2009 Christoph Reiter <christoph.reiter@gmx.at>
#
# This program is free software; you can redistribute it and/or modify
# it under the terms of the GNU General Public License version 2 as
# published by the Free Software Foundation.

import os
import sys
import subprocess
import threading
import pickle
import signal

import gtk
import gobject

import ttk
import trayicon
import freqtable
import util
import v4l2
import teletext

class Scanner(gtk.HBox):
    active = False

    def __init__(self, fun, clear):
        super(Scanner, self).__init__()

        self.__thread = None
        self.__thread_stop = False

        self.set_spacing(6)

        self.checkb = checkb = gtk.CheckButton(
            "_Try to get channel names", True)
        self.pack_start(checkb, False)

        pb = gtk.ProgressBar()
        self.pack_start(pb)

        cb = gtk.combo_box_new_text()
        cb.append_text("All")
        for n in sorted(freqtable.mapping.keys()):
            txt = "-".join([str[:1].upper() + str[1:] for str in n.split("-")])
            cb.append_text(txt)
        cb.set_active(0)
        self.pack_start(cb, False)

        bcancel = gtk.Button(None,gtk.STOCK_CANCEL)
        self.pack_start(bcancel, False)

        bsearch = gtk.Button(None,gtk.STOCK_FIND)
        self.pack_start(bsearch, False)

        bsearch.connect("clicked", self.__scan_start, cb, pb, fun, clear)
        bcancel.connect("clicked", self.__scan_stop)

        self.connect("destroy", self.__scan_stop)

        self.show_all()

    def __scan_start(self, widget, cb, pb, fun, clear):
        if self.__thread is None:
            if self.checkb.get_active() and not util.iscommand("alevt-cap"):
                ttk.ErrorMessage(None, "alevt-cap not found",
                    "It is needed for getting the channel name\n"
                    "Install (debian): apt-get install alevt").run()
                return

            type(self).active = True
            self.__thread = thread = threading.Thread(
                target=self.__scanner,
                args=(cb.get_active_text(), pb, fun, clear))
            thread.setDaemon(True)
            thread.start()

    def __scan_stop(self, widget):
        self.__thread_stop = True
        if self.__thread:
            self.__thread.join()
        self.__thread = None
        self.__thread_stop = False

    def __scanner(self, freq, pb, fun, clear):
        clear()
        freq = freq.lower()
        search_list = []
        if freq in freqtable.mapping:
            search_list = freqtable.mapping[freq]
        else:
            tmp = freqtable.mapping.values()
            map(search_list.extend, tmp)

        search_list = sorted(list(set(search_list)))

        for num, freq in enumerate(search_list):
            if self.__thread_stop: break
            progress = float(num + 1) / len(search_list)
            gobject.idle_add(pb.set_fraction, progress)
            gobject.idle_add(pb.set_text, "%0.1f%%" % (progress*100))
            v4l2.set_frequency(freq)
            for x in range(5):
                if v4l2.get_signal():
                    title = ""
                    if self.checkb.get_active():
                        title = teletext.get_current_title()
                    gobject.idle_add(fun, (freq, title))
                    break

        gobject.idle_add(pb.set_text, "")
        gobject.idle_add(pb.set_fraction, 0.0)
        self.__thread_stop = False
        self.__thread = None
        type(self).active = False

class ChannelList(gtk.VBox):
    def __init__(self, name, select, edit=False):
        super(ChannelList, self).__init__()

        self.set_spacing(10)

        label = gtk.Label(name + ":")
        self.pack_start(label, False)

        self.ls = ls = gtk.ListStore(float, str)
        self.clear = ls.clear
        tv = gtk.TreeView(ls)
        self.sel = tv.get_selection()
        self.sel.connect("changed", select)
        tvc_f = gtk.TreeViewColumn("Frequency")
        tv.append_column(tvc_f)

        tvc_n = gtk.TreeViewColumn("Name")
        tv.append_column(tvc_n)

        def cell_data_freq(column, cell, model, iter):
            num = model.get_value(iter, 0)
            cell.set_property("text", "%0.2f" % num)

        def cell_data_name(column, cell, model, iter):
            if not model.get_value(iter, 1):
                cell.set_property("text", "-")

        def edited_name(render, path, text, model):
            model[model.get_iter_from_string(path)][1] = text
            self.sel.emit("changed")

        def edited_freq(render, path, text, model):
            try:
                model[model.get_iter_from_string(path)][0] = float(text)
            except ValueError:
                pass
            else:
                self.sel.emit("changed")

        render = gtk.CellRendererText()
        render.set_property("editable", True)
        render.connect("edited", edited_freq, ls)
        tvc_f.pack_start(render)
        tvc_f.add_attribute(render, "text", 0)
        tvc_f.set_cell_data_func(render, cell_data_freq)

        render2 = gtk.CellRendererText()
        render2.set_property("editable", True)
        render2.connect("edited", edited_name, ls)
        tvc_n.pack_start(render2)
        tvc_n.add_attribute(render2, "text", 1)
        tvc_n.set_cell_data_func(render2, cell_data_name)

        sw = gtk.ScrolledWindow()
        sw.set_policy(gtk.POLICY_NEVER, gtk.POLICY_AUTOMATIC)
        sw.set_shadow_type(gtk.SHADOW_ETCHED_IN)
        sw.add(tv)

        self.pack_start(sw)

        hbox = gtk.HBox(spacing=6)

        if edit:
            bup = gtk.Button()
            bup.set_image(
                gtk.image_new_from_stock(gtk.STOCK_GO_UP, gtk.ICON_SIZE_MENU))
            bup.connect("clicked", self.__up)
            bdown = gtk.Button()
            bdown.set_image(
                gtk.image_new_from_stock(gtk.STOCK_GO_DOWN,gtk.ICON_SIZE_MENU))
            bdown.connect("clicked", self.__down)
            bdelete = gtk.Button(None,gtk.STOCK_DELETE)
            bdelete.connect("clicked", self.__delete)
            bnew = gtk.Button(None,gtk.STOCK_NEW)
            bnew.connect("clicked", self.__new)

            map(hbox.pack_start, [bup, bdown, bdelete, bnew])

        self.pack_start(hbox, False)

        self.show_all()

    def __new(self, button):
        model, iter = self.sel.get_selected()
        model.insert_after(iter, [0, ""])

    def __delete(self, button):
        model, iter = self.sel.get_selected()
        model.remove(iter)

    def __up(self, button):
        model, iter = self.sel.get_selected()
        try:
            path = model.get_path(iter)[0]-1
            if path < 0: return
            bef = model.get_iter(path)
            model.move_before(iter, bef)
        except ValueError:
            pass

    def __down(self, button):
        model, iter = self.sel.get_selected()
        try:
            nxt = model.get_iter(model.get_path(iter)[0]+1)
            model.move_after(iter, nxt)
        except ValueError:
            pass

    def add_channel(self, channel):
        if channel:
            self.ls.append(channel)

    def get_channel(self):
        model, iter = self.sel.get_selected()
        try:
            return list(model[iter])
        except TypeError:
            return []

    def get_all_channels(self):
        chans = []
        for row in self.ls:
            chans.append(list(row))
        return chans

class ChannelManager(ttk.UniqueWindow):
    def __init__(self, sel_chan, clist, uplist):
        if self.is_not_unique(): return
        super(ChannelManager, self).__init__()

        self.set_title("Channel manager - IVTV tray")
        self.set_default_size(550, 400)
        self.set_border_width(10)
        icon_path = os.path.join(util.IMAGEDIR, "ivtvt.png")
        self.set_icon_from_file(icon_path)

        list_box = gtk.HBox(spacing=10)

        self.sel_chan = sel_chan
        self.cl = cl = ChannelList("Search list", select=self.__select)
        self.cl2 = cl2 = ChannelList("Menu list",
            edit=True, select=self.__select)
        map(cl2.add_channel, clist)

        list_box.pack_start(cl)

        middle_box = gtk.VBox(spacing=10)
        bright = gtk.Button()
        bright.connect("clicked", self.__add_from_search_list, cl, cl2)
        bright.set_image(
            gtk.image_new_from_stock(gtk.STOCK_GO_FORWARD, gtk.ICON_SIZE_MENU))
        middle_box.pack_start(bright, True, False)

        list_box.pack_start(middle_box, False)
        list_box.pack_start(cl2)

        vbox = gtk.VBox(spacing=10)

        self.scanner = Scanner(self.__update, self.__clear)
        vbox.pack_start(self.scanner, False)
        vbox.pack_start(list_box)

        self.connect("destroy", self.__destroy, uplist)

        self.add(vbox)
        self.show_all()

    def __add_from_search_list(self, button, cl, cl2):
        cl2.add_channel(cl.get_channel())

    def __select(self, selection):
        model, iter = selection.get_selected()
        try:
            self.sel_chan(list(model[iter]))
        except TypeError:
            pass

    def __update(self, entry):
        self.cl.add_channel(entry)

    def __clear(self):
        self.cl.clear()

    def __destroy(self, win, uplist):
        uplist(self.cl2.get_all_channels())

class IvtvTray(trayicon.Trayicon):
    def __init__(self):
        super(IvtvTray, self).__init__()
        self.set_tooltip("IVTV tray")

        user_dir = os.path.expanduser("~")
        config_dir = os.getenv("XDG_CONFIG_HOME",
            os.path.join(user_dir, ".config"))
        self.filename = os.path.join(config_dir, "ivtvtray")
        if not os.path.isdir(config_dir):
            os.mkdir(config_dir, 0755)

        self.channel_list = []
        try:
            f = open(self.filename, "r")
            self.channel_list, util.settings = pickle.load(f)
            f.close()
        except IOError:
            pass

        if "current" in util.settings:
            self.__set_channel(util.settings["current"])
        elif self.channel_list:
            self.__set_channel(self.channel_list[0])

        if "input_video" in util.settings:
            v4l2.set_video_input(util.settings["input_video"])

        if "input_audio" in util.settings:
            v4l2.set_audio_input(util.settings["input_audio"])

        icon_path = os.path.join(util.IMAGEDIR, "ivtvt.png")
        pb = gtk.gdk.pixbuf_new_from_file_at_size(icon_path, 16, 16)
        self.set_from_pixbuf(pb)
        self.connect("button-press-event", self.__menu)
        self.connect("scroll-event", self.__scroll)

        SIGNALS = [signal.SIGINT, signal.SIGTERM, signal.SIGHUP]
        for sig in SIGNALS:
            signal.signal(sig, self.__quit)

    def __update_list(self, new_list):
        self.channel_list = new_list

    def __main_menu(self, icon, event):
        main_menu = gtk.Menu()

        vlc = gtk.ImageMenuItem(ttk.START_PLAYER)
        vlc.connect("activate", self.__start_vlc)
        main_menu.add(vlc)

        txt = gtk.ImageMenuItem(ttk.TELETEXT)
        txt.connect("activate", self.__start_teletext)
        main_menu.add(txt)

        main_menu.add(gtk.SeparatorMenuItem())

        chan_sub = gtk.Menu()
        for c in self.channel_list:
            title = c[1] or c[0]
            mi = gtk.MenuItem("%s" % str(title))
            mi.connect_object("activate", self.__set_channel, c)
            main_menu.add(mi)

        if not self.channel_list:
            main_menu.add(gtk.MenuItem("No channels"))

        main_menu.show_all()

        if trayicon.gtk_216:
            main_menu.popup(None, None, gtk.status_icon_position_menu,
                event.button, event.time, icon)
        else:
            main_menu.popup(None, None, icon.place_menu,
                event.button, event.time)

    def __pref_menu(self, icon, event):
        main_menu = gtk.Menu()
        vi_sub = self.__create_video_input_menu()
        ai_sub = self.__create_audio_input_menu()

        video_input = gtk.MenuItem("_Video Input")
        video_input.set_submenu(vi_sub)
        audio_input = gtk.MenuItem("_Audio Input")
        audio_input.set_submenu(ai_sub)
        main_menu.add(video_input)
        main_menu.add(audio_input)

        test = gtk.ImageMenuItem(ttk.PREFERENCES)
        test.connect_object("activate", ChannelManager,
            self.__set_channel, self.channel_list, self.__update_list)
        main_menu.add(test)

        main_menu.add(gtk.SeparatorMenuItem())

        about = gtk.ImageMenuItem(gtk.STOCK_ABOUT)
        about.connect("activate", self.__show_about)
        main_menu.add(about)

        quit = gtk.ImageMenuItem(gtk.STOCK_QUIT)
        quit.connect('activate', self.__quit)
        main_menu.add(quit)

        main_menu.show_all()

        if trayicon.gtk_216:
            main_menu.popup(None, None, gtk.status_icon_position_menu,
                event.button, event.time, icon)
        else:
            main_menu.popup(None, None, icon.place_menu,
                event.button, event.time)

    def __menu(self, icon, event):
        if event.button == 1:
            self.__main_menu(icon, event)
        elif event.button == 2:
            self.__start_vlc()
        elif event.button == 3:
            self.__pref_menu(icon, event)

    def __scroll(self, icon, event):
        if not self.channel_list:
            return

        for i,c in enumerate(self.channel_list):
            if c == util.settings["current"]:
                index = i
                break
        else:
            index = 0

        if event.direction == gtk.gdk.SCROLL_DOWN:
            if i < len(self.channel_list)-1:
                new = self.channel_list[i+1]
                util.settings["current"] = new
                self.__set_channel(new)
        else:
            if i > 0:
                new = self.channel_list[i-1]
                util.settings["current"] = new
                self.__set_channel(new)

    def __create_video_input_menu(self):
        inputs = v4l2.get_video_input_list()
        current = v4l2.get_video_input()

        menu = gtk.Menu()
        for i in inputs:
            name, val = i
            mi = gtk.CheckMenuItem(name)
            if val == current[1]:
                mi.set_active(True)
            mi.connect_object("activate", self.__set_video_input, val)
            menu.add(mi)
        menu.show_all()
        return menu

    def __create_audio_input_menu(self):
        inputs = v4l2.get_audio_input_list()
        current = v4l2.get_audio_input()

        menu = gtk.Menu()
        for i in inputs:
            name, val = i
            mi = gtk.CheckMenuItem(name)
            if val == current[1]:
                mi.set_active(True)
            mi.connect_object("activate", self.__set_audio_input, val)
            menu.add(mi)
        menu.show_all()
        return menu

    def __start_vlc(self, *args):
        if not util.iscommand("vlc"):
            ttk.ErrorMessage(None, "vlc not found",
                            "vlc is needed for watching TV\n"
                            "Install (debian): apt-get install vlc").run()
        util.start_process("vlc pvr://dev/video0 --vout-filter deinterlace "
            "--deinterlace-mode=blend")

    def __start_teletext(self, *args):
        if not util.iscommand("alevt"):
            ttk.ErrorMessage(None, "alevt not found",
                            "It is needed for reading teletext\n"
                            "Install (debian): apt-get install alevt").run()
        util.start_process("alevt")

    def __set_audio_input(self, val):
        v4l2.set_audio_input(val)
        util.settings["input_audio"] = val

    def __set_video_input(self, val):
        v4l2.set_video_input(val)
        util.settings["input_video"] = val

    def __set_channel(self, pair):
        if not Scanner.active:
            util.settings["current"] = pair
            v4l2.set_frequency(pair[0])
            self.set_tooltip("%s (%0.2f)" % (pair[1], pair[0]))

    def __show_about(self, *args):
        about = AboutDialog()
        about.run()
        about.destroy()

    def __quit(self, *args):
        print "saving.."
        try:
            f = open(self.filename, "w")
            pickle.dump((self.channel_list, util.settings), f)
            f.close()
        except IOError:
            print "saving failed"
        else:
            print "saving done"
        gtk.main_quit()

class AboutDialog(gtk.AboutDialog):
    def __init__(self):
        super(AboutDialog, self).__init__()

        icon_path = os.path.join(util.IMAGEDIR, "ivtvt.png")
        pb = gtk.gdk.pixbuf_new_from_file_at_size(icon_path, 48, 48)

        self.set_name("IVTV Tray")
        self.set_version("0.11")
        self.set_logo(pb)
        self.set_authors(["Christoph Reiter"])
        self.set_website("http://www.student.tugraz.at/christoph.reiter/")
        self.set_comments("A program to make program switching for\n"
            "ivtv users easier...")
        self.set_copyright("Copyright 2009 Christoph Reiter\n"
            "<christoph.reiter@gmx.at>")

        self.show_all()

if __name__ == "__main__":
    ttk.stock_init()

    app = IvtvTray()

    gtk.gdk.threads_init()
    gtk.main()
