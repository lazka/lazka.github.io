# Copyright 2009 Christoph Reiter <christoph.reiter@gmx.at>
#
# This program is free software; you can redistribute it and/or modify
# it under the terms of the GNU General Public License version 2 as
# published by the Free Software Foundation.

import gtk

def stock_init():
    global CHANNEL_SELECT, PREFERENCES, START_PLAYER, TELETEXT
    VIDEO_INPUT = "ivtvt-video-input"
    AUDIO_INPUT = "ivtvt-audio-input"
    PREFERENCES = "ivtvt-prefs"
    START_PLAYER = "ivtvt-start-player"
    CHANNEL_SELECT = "ivtvt-chan-select"
    TELETEXT = "ivtvt-teletext"

    gtk.stock_add([
        (CHANNEL_SELECT, "_Channels", 0, 0, ""),
        (PREFERENCES, "_Edit Channels", 0, 0, ""),
        (START_PLAYER, "_Start Player", 0, 0, ""),
        (TELETEXT, "_View Teletext", 0, 0, "")
        ])

    factory = gtk.IconFactory()
    lookup = gtk.icon_factory_lookup_default
    factory.add(CHANNEL_SELECT, lookup(gtk.STOCK_INDEX))
    factory.add(PREFERENCES, lookup(gtk.STOCK_PREFERENCES))
    factory.add(START_PLAYER, lookup(gtk.STOCK_MEDIA_PLAY))
    factory.add(TELETEXT, lookup(gtk.STOCK_DND))
    factory.add_default()

class Message(gtk.MessageDialog):
    """A message dialog that destroys itself after it is run, uses
    markup, and defaults to an 'OK' button."""

    def __init__(
        self, kind, parent, title, description, buttons=gtk.BUTTONS_OK):
        #parent = get_top_parent(parent)
        text = "<span size='xx-large'>%s</span>\n\n%s" % (title, description)
        super(Message, self).__init__(
            parent, gtk.DIALOG_MODAL | gtk.DIALOG_DESTROY_WITH_PARENT,
            kind, buttons)
        self.set_markup(text)

    def run(self, destroy=True):
        resp = super(Message, self).run()
        if destroy: self.destroy()
        return resp

class ErrorMessage(Message):
    """Like Message, but uses an error-indicating picture."""
    def __init__(self, *args, **kwargs):
        super(ErrorMessage, self).__init__(gtk.MESSAGE_ERROR, *args, **kwargs)

class WarningMessage(Message):
    """Like Message, but uses an warning-indicating picture."""
    def __init__(self, *args, **kwargs):
        super(WarningMessage, self).__init__(
            gtk.MESSAGE_WARNING, *args, **kwargs)

class UniqueWindow(gtk.Window):
    """A wrapper for the window class to get a one instance per class window.
    The is_not_unique method will return True if the window
    is already there."""

    __window = None

    def __new__(klass, *args):
        if klass.__window is None:
            return super(UniqueWindow, klass).__new__(klass, *args)
        else:
            klass.__window.present()
            return klass.__window

    def is_not_unique(self):
        if type(self).__window:
            return True

    def __init__(self, *args, **kwargs):
        if type(self).__window: return
        else: type(self).__window = self
        super(UniqueWindow, self).__init__(*args, **kwargs)
        self.connect_object('delete-event', self.__delete, self)

    def __delete(self, *args):
        type(self).__window = None
