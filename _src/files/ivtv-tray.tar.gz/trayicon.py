# Copyright 2009 Christoph Reiter <christoph.reiter@gmx.at>
#
# This program is free software; you can redistribute it and/or modify
# it under the terms of the GNU General Public License version 2 as
# published by the Free Software Foundation.

import gtk

gtk_216 = gtk.gtk_version >= (2, 16)
if not gtk_216:
    try:
        import egg.trayicon as trayicon
    except ImportError:
        import sys
        print "eggtrayicon or gtk+ >= 2.16 is needed"
        sys.exit()

class EggTrayIconWrapper():
    def __init__(self):
        self.__popup_sig = None
        self.__activate_sig = None
        self.__button_press_sig = None
        self.__size_changed_sig = None
        self.__icon = trayicon.TrayIcon("ivtvtray")
        self.__eb = gtk.EventBox()
        self.__image = gtk.Image()
        self.__eb.add(self.__image)
        self.__icon.add(self.__eb)
        self.__icon.show_all()
        self.__tips = gtk.Tooltips()
        self.__icon.connect_object('destroy',
            gtk.Tooltips.destroy, self.__tips)
        self.__tips.enable()

        self.__eb.connect("size-allocate", self.__size_changed)
        self.__eb.connect("button-press-event", self.__button_press)

    def destroy(self):
        if self.__icon:
            self.__icon.destroy()

    def connect(self, *args):
        if args[0] == "button-press-event":
            self.__button_press_sig = args[1]
        elif args[0] == "scroll-event":
            return self.__eb.connect(*args)
        return None

    def __button_press(self, eb, event):
        if event.type == gtk.gdk.BUTTON_PRESS and self.__button_press_sig:
            self.__button_press_sig(self, event)

    def __size_changed(self, eb, rect):
        if self.__size_changed_sig:
            self.__size_changed_sig(eb, rect.height)

    def set_visible(self, val):
        if val:
            self.__icon.show()
        else:
            self.__icon.hide()

    def set_from_pixbuf(self, pb):
        self.__image.set_from_pixbuf(pb)

    def set_from_file(self, file):
        self.__image.set_from_file(file)

    def set_from_stock(self, file):
        self.__image.set_from_stock(file, gtk.ICON_SIZE_MENU)

    def set_tooltip(self, tip):
        self.__tips.set_tip(self.__icon, tip)

    def place_menu(self, menu):
        (width, height) = menu.size_request()
        (menu_xpos, menu_ypos) = self.__icon.window.get_origin()
        menu_xpos += self.__icon.allocation.x
        menu_ypos += self.__icon.allocation.y
        if menu_ypos > self.__icon.get_screen().get_height() / 2:
            menu_ypos -= height
        else:
            menu_ypos += self.__icon.allocation.height
        return (menu_xpos, menu_ypos, True)

if gtk_216:
    Trayicon = gtk.StatusIcon
else:
    Trayicon = EggTrayIconWrapper
