# Copyright 2009 Christoph Reiter <christoph.reiter@gmx.at>
#
# This program is free software; you can redistribute it and/or modify
# it under the terms of the GNU General Public License version 2 as
# published by the Free Software Foundation.

import os

def start_process(cmd):
    from subprocess import Popen, PIPE
    print cmd
    p = Popen(cmd, shell=True, stdout=PIPE, stderr=PIPE)
    return p

def get_status_output(cmd):
    p = start_process(cmd)
    stdout, stderr = p.communicate()
    return p.returncode, stdout.strip()

def iscommand(s):
    """True if an executable file 's' exists in the user's path, or is a
    fully-qualified existing executable file."""

    if s == "" or os.path.sep in s:
        return (os.path.isfile(s) and os.access(s, os.X_OK))
    else:
        s = s.split()[0]
        for p in os.defpath.split(os.path.pathsep):
            p2 = os.path.join(p, s)
            if (os.path.isfile(p2) and os.access(p2, os.X_OK)):
                return True
        else: return False

settings = {}

BASEDIR = os.path.dirname(os.path.realpath(__file__))
IMAGEDIR = os.path.join(BASEDIR, "images")
