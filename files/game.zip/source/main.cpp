#include <stdio.h>
#include <conio.h>
#include "ic/ic.h"

int main(void)
{
	int y, x;
	unsigned char sign;
	int point, box1, box2, hole, player_y, flag, gameover, speed;

	while(1)
	{
    	point=0; box1=45; box2=-4; hole=12; player_y=0; flag=0; gameover=0, speed=0;
   		con.setTitle(_T("Lazka's Jump&Run"));
   		con.setSize(50,25);
   		con.setBgColor(static_cast<BgColor>(112));
		con.setTextColor(static_cast<TextColor>(0));

		while(!gameover)
		{
	        /* Generiern der "Grafik" */
			for(x=0;x<=49;x++)
			{
				for(y=5;y<=19;y++)
				{
					/* Box 1 */
					if((x>=box1 && x<=box1+3) && y<=14 && y>=12)
					{
                        con.setBgColor(static_cast<BgColor>(224));
					    sign=32;
					}
					/* Box 1 */
					else if((x>=box2 && x<=box2+3) && y<=14 && y>=12)
					{
                        con.setBgColor(static_cast<BgColor>(64));
					    sign=32;
					}
					/* Player */
					else if(x==24 && (y+player_y)==12)
					    sign=184;
					else if((x==25 || x==23) && (y+player_y)==12)
					    sign='_';
					else if(x==24 && (y+player_y)==13)
					    sign='#';
					else if(x==23 && (y+player_y)==14)
					    sign='/';
					else if(x==25 && (y+player_y)==14)
					    sign='\\';
					/* Loch */
	  				else if(x>hole && x<hole+9 && y==19)
					{
                        con.setTextColor(static_cast<TextColor>(12));
					    sign='^';
					}
	  				else if(x>hole && x<hole+9 && y>=15 && y<=18)
					    sign=' ';

					/* Boden */
    				else if(y>=15 && y<=18)
					{
                        con.setBgColor(static_cast<BgColor>(32));
					    sign=32;
					}
					/* Sonstiges */
			   		else
					   sign=' ';
					/* Zeichnen und reset der Farben */
			   		con.setCaret(x,y);
			  		printf("%c",sign);
			  		if(con.getTextColor() != 15)
			  			con.setTextColor(static_cast<TextColor>(15));
					if(con.getBgColor() != 0)
       					con.setBgColor(static_cast<BgColor>(0));
				}
			}

			/* Aktueller Punktestand */
			con.setCaret(19,21);
			printf("Points: %d",point);

			/* Game-Over wenn in Box oder am Boden von Loch */
			if((player_y<3 && ((box1<=25 && box1>=20) || (box2<=25 && box2>=20))) || player_y<-4)
			{
				con.setCaret(16,7);
				printf("--- GAME OVER! ---");
				gameover=1;
			}

			/* Pause, immer weniger */
			Sleep(2);
			if(speed<40)
				Sleep(40-speed);

			/* H�pfen */
			if((kbhit() && player_y==0) || player_y>0)
			{
				if(!flag)
				{
	                if(player_y>=6)
			    	    flag=1;
			    	player_y++;
				}
				else if(flag<5)
				    flag++;
				else
				{
					if(player_y>0)
				    	player_y--;
					else
					{
					    flag=0;
					    while(kbhit())
	    			    	getch();
					}
				}
			}


			/* Ins Loch fallen */
	        if(hole<=22 && hole>=17 && player_y<=0)
	        {
				player_y--;
			}
			else
			{
		        box1--;
		        box2--;
				hole--;
				point++;
			}

			/*	Wenn Loch bzw. Box aus Screen verschwindet dann zuf�llig neue generieren
				und schaun dass sie sich nicht zu nahe kommen */
			if(hole<=-10 && box2<=-4 && rand()<20000)
			{
			    hole=50+(rand()/1200);
				if(hole<(box1+25))
				    hole+=25;
				speed++;
			}
			else if(hole<=-10 && box2<=-4)
			{
			    box2=50+(rand()/1200);
				if(box2<(box1+25))
				    box2+=25;
				speed++;
			}

			if(box1<=-4)
			{
			    box1=50+(rand()/1200);
				if(box1<(hole+25) || box1<(box2+25))
				    box1+=25;
                speed++;
			}
		}


		/* Abfrage ob Neubeginn oder exit */
		con.setCaret(9,9);
		printf("Do you want to try again? [y/n]:");
		while(kbhit())
	    	getch();
		while((sign=getch())!='y' && sign!='n');
		if(sign=='y')
		{
			clrscr();
			continue;
		}
		else
			break;
	}

    return 0;
}
