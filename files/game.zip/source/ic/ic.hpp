///// Configuration ////////////////////////////////////////////////////////////
#define IMPROVED_CONSOLE_WIN9X_COMPATIBLE
////////////////////////////////////////////////////////////////////////////////

#ifndef INCLUDE_GUARD_IC_HPP
#define INCLUDE_GUARD_IC_HPP

///// Compatibility-mode check /////////////////////////////////////////////////
#ifndef IMPROVED_CONSOLE_WIN9X_COMPATIBLE
#define _WIN32_WINNT 0x0500
#endif
////////////////////////////////////////////////////////////////////////////////

///// Macros ///////////////////////////////////////////////////////////////////
#ifndef IMPROVED_CONSOLE_WIN9X_COMPATIBLE
#define CONSOLE_FULLSCREEN_MODE 1
#define CONSOLE_WINDOWED_MODE 2
#endif
////////////////////////////////////////////////////////////////////////////////

///// Includes /////////////////////////////////////////////////////////////////
#include <string>
#include <tchar.h>
#include <windows.h>
////////////////////////////////////////////////////////////////////////////////

namespace ic
{
	///// Types ////////////////////////////////////////////////////////////////
	typedef WORD Color;
	////////////////////////////////////////////////////////////////////////////

	///// TextColor ////////////////////////////////////////////////////////////
	enum TextColor
	{
		FG_BLACK		= 0,
		FG_DARKRED		= FOREGROUND_RED,
		FG_DARKGREEN	= FOREGROUND_GREEN,
		FG_DARKBLUE		= FOREGROUND_BLUE,
		FG_OCHER		= FOREGROUND_RED | FOREGROUND_GREEN,
		FG_VIOLET		= FOREGROUND_RED | FOREGROUND_BLUE,
		FG_TURQUOISE	= FOREGROUND_GREEN | FOREGROUND_BLUE,
		FG_GREY			= FOREGROUND_RED | FOREGROUND_GREEN | FOREGROUND_BLUE,

		FG_DARKGREY		= FOREGROUND_INTENSITY,        
		FG_RED			= FOREGROUND_INTENSITY | FOREGROUND_RED,        
		FG_GREEN		= FOREGROUND_INTENSITY | FOREGROUND_GREEN,        
		FG_BLUE			= FOREGROUND_INTENSITY | FOREGROUND_BLUE,
		FG_YELLOW		= FOREGROUND_INTENSITY | FOREGROUND_RED | FOREGROUND_GREEN,
		FG_PINK			= FOREGROUND_INTENSITY | FOREGROUND_RED | FOREGROUND_BLUE,
		FG_LIGHTBLUE	= FOREGROUND_INTENSITY | FOREGROUND_GREEN | FOREGROUND_BLUE,
		FG_WHITE		= FOREGROUND_INTENSITY | FOREGROUND_RED | FOREGROUND_GREEN | FOREGROUND_BLUE
	};
	////////////////////////////////////////////////////////////////////////////

	///// BgColor //////////////////////////////////////////////////////////////
	enum BgColor
	{
		BG_BLACK		= 0,
		BG_DARKRED		= BACKGROUND_RED,
		BG_DARKGREEN	= BACKGROUND_GREEN,
		BG_DARKBLUE		= BACKGROUND_BLUE,
		BG_OCHER		= BACKGROUND_RED | BACKGROUND_GREEN,
		BG_VIOLET		= BACKGROUND_RED | BACKGROUND_BLUE,
		BG_TURQUOISE	= BACKGROUND_GREEN | BACKGROUND_BLUE,
		BG_GREY			= BACKGROUND_RED | BACKGROUND_GREEN | BACKGROUND_BLUE,

		BG_DARKGREY		= BACKGROUND_INTENSITY,        
		BG_RED			= BACKGROUND_INTENSITY | BACKGROUND_RED,        
		BG_GREEN		= BACKGROUND_INTENSITY | BACKGROUND_GREEN,        
		BG_BLUE			= BACKGROUND_INTENSITY | BACKGROUND_BLUE,
		BG_YELLOW		= BACKGROUND_INTENSITY | BACKGROUND_RED | BACKGROUND_GREEN,
		BG_PINK			= BACKGROUND_INTENSITY | BACKGROUND_RED | BACKGROUND_BLUE,
		BG_LIGHTBLUE	= BACKGROUND_INTENSITY | BACKGROUND_GREEN | BACKGROUND_BLUE,
		BG_WHITE		= BACKGROUND_INTENSITY | BACKGROUND_RED | BACKGROUND_GREEN | BACKGROUND_BLUE
	};
	////////////////////////////////////////////////////////////////////////////

	///// CaretSize ////////////////////////////////////////////////////////////
	enum CaretSize
	{
		CARET_OFF		= 0,
		CARET_INSERT	= 10,
		CARET_OVERWRITE	= 100
	};
	////////////////////////////////////////////////////////////////////////////

	///// Console //////////////////////////////////////////////////////////////
	class Console
	{
		// Type-aliases
		typedef CONSOLE_CURSOR_INFO CCI;
		typedef CONSOLE_SCREEN_BUFFER_INFO CSBI;

#ifndef IMPROVED_CONSOLE_WIN9X_COMPATIBLE
		// Already implemented WinAPI-Functions without declaration in <windows.h>
		typedef BOOL (WINAPI *SETCONSOLEDISPLAYMODE) (HANDLE,DWORD,PCOORD);
		SETCONSOLEDISPLAYMODE SetConsoleDisplayMode;
#endif

		// Coordinate-system origin
		static const COORD origin;
		// Standard output handle
		HANDLE hout;

		// Constructors
		Console ();
	public:
		~Console ();

		// Access
		static Console& getInstance ();

		// Reset system
		void reset ();

		// Show/Hide console window
		void show ();
		void hide ();

		// Switch console window to normal/minimized/maximized mode
		void normalize ();
		void minimize ();
		void maximize ();

		// Toggles fullscreen-mode (Hack, should only be used in compatibility-mode)
		void toggleFullscreen ();

		// Clear: Only color, only text or both
		void clearColor (Color color = FG_WHITE | BG_BLACK);
		void clearText (TCHAR character = TEXT(' '));
		void clearScreen (Color color = FG_WHITE | BG_BLACK, TCHAR character = TEXT(' '));

		// Get/Set: Text color
		TextColor getTextColor () const;
		void setTextColor (TextColor color);

		// Get/Set: Background color
		BgColor getBgColor () const;
		void setBgColor (BgColor color);

		// Get/Set: Caret position
		WORD getCaretX () const;
		WORD getCaretY () const;
		void setCaret (WORD x, WORD y);

		// Get/Set: Caret size
		DWORD getCaretSize () const;
		void setCaretSize (DWORD size);

		// Get/Set: Window position
		DWORD getPosX () const;
		DWORD getPosY () const;
		void setPos (DWORD x, DWORD y);

		// Get/Set: Window size
		WORD getSizeX () const;
		WORD getSizeY () const;
		void setSize (WORD x, WORD y);

		// Get: Maximal window size
		WORD getMaxSizeX () const;
		WORD getMaxSizeY () const;

		// Get/Set: Window title
		std::basic_string<TCHAR> getTitle () const;
		void setTitle (const std::basic_string<TCHAR>& title);

#ifndef IMPROVED_CONSOLE_WIN9X_COMPATIBLE
		// Get/Set: Fullscreen-mode
		bool isFullscreen () const;
		void setFullscreen (bool on = true);
#endif

		// Aliases for backward-compatibility to former IC-versions
		inline void normal () { normalize(); }
#ifndef IMPROVED_CONSOLE_WIN9X_COMPATIBLE
		inline void fullscreen (bool on = true) { setFullscreen(on); }
#endif

	private:
		// Helper
		CCI getCCI () const;
		CSBI getCSBI () const;
		HWND getCWND () const;

#ifndef IMPROVED_CONSOLE_WIN9X_COMPATIBLE
		// Helper: Console()
		void loadUndeclaredFunctions ();
#endif

		// Helper: getBgColor()/getTextColor()
		inline BgColor getBgColor (Color color) const { return static_cast<BgColor>(color & 0xF0); }
		inline TextColor getTextColor (Color color) const { return static_cast<TextColor>(color & 0x0F); }

		// Helper: setSize()
		void zeroSize ();

		// Forbidden
		Console (const Console&);
		Console& operator= (const Console&);
	};

	extern Console& con;
	////////////////////////////////////////////////////////////////////////////

	///// Shorties /////////////////////////////////////////////////////////////
	namespace shorties
	{
		inline void bgcolor (BgColor color) { con.setBgColor(color); }
		inline void clrcol (Color color = FG_WHITE | BG_BLACK) { con.clearColor(color); }
		inline void clrscr (Color color = FG_WHITE | BG_BLACK, TCHAR character = TEXT(' ')) { con.clearScreen(color,character); }
		inline void clrtext (TCHAR character = TEXT(' ')) { con.clearText(character); }
#ifndef IMPROVED_CONSOLE_WIN9X_COMPATIBLE
		inline void fullscreen (bool on = true) { con.setFullscreen(on); }
#endif
		inline void gotoxy (SHORT x, SHORT y) { con.setCaret(x,y); }
		inline void home () { con.setCaret(0,0); }
		inline void resize (SHORT x, SHORT y) { con.setSize(x,y); }
		inline void textcolor (TextColor color) { con.setTextColor(color); }
		inline void title (const std::basic_string<TCHAR>& title) { con.setTitle(title); }
	}
	////////////////////////////////////////////////////////////////////////////
}

#endif
